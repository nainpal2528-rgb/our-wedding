(function () {
    "use strict";

    function qs(sel, root) { return (root || document).querySelector(sel); }
    function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

    function initHeader() {
        var h = qs("header");
        if (!h) return;
        window.addEventListener("scroll", function () {
            h.classList.toggle("scrolled", window.scrollY > 12);
        });
    }

    function initCarousel() {
        var slides = qsa(".slide");
        var dots = qsa(".c-dot");
        if (!slides.length) return;
        var i = 0, timer;
        function show(n) {
            i = (n + slides.length) % slides.length;
            slides.forEach(function (s, idx) { s.classList.toggle("active", idx === i); });
            dots.forEach(function (d, idx) { d.classList.toggle("active", idx === i); });
        }
        function next() { show(i + 1); }
        function prev() { show(i - 1); }
        function start() { stop(); timer = setInterval(next, 4500); }
        function stop() { if (timer) clearInterval(timer); }
        dots.forEach(function (d, idx) { d.addEventListener("click", function () { show(idx); start(); }); });
        var n = qs(".c-nav.next"), p = qs(".c-nav.prev");
        if (n) n.addEventListener("click", function () { next(); start(); });
        if (p) p.addEventListener("click", function () { prev(); start(); });
        var box = qs("#heroCarousel");
        if (box) {
            var x0 = 0;
            box.addEventListener("mouseenter", stop);
            box.addEventListener("mouseleave", start);
            box.addEventListener("touchstart", function (e) { x0 = e.changedTouches[0].screenX; }, { passive: true });
            box.addEventListener("touchend", function (e) {
                var dx = e.changedTouches[0].screenX - x0;
                if (Math.abs(dx) > 40) { if (dx < 0) next(); else prev(); start(); }
            });
        }
        start();
    }

    function bindForm(form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            var nameEl = form.querySelector('[name="name"]');
            var phoneEl = form.querySelector('[name="phone"]');
            var msg = form.querySelector(".msg");
            var btn = form.querySelector(".submit");
            var thanks = form.parentElement.querySelector(".thanks");
            var privacy = form.querySelector('[name="privacy"]');
            var name = ((nameEl && nameEl.value) || "").trim();
            var phone = ((phoneEl && phoneEl.value) || "").replace(/\D/g, "");
            if (msg) { msg.className = "msg"; msg.textContent = ""; }
            if (!name) { if (msg) { msg.textContent = "Please enter your full name."; msg.classList.add("show", "err"); } return; }
            if (phone.length !== 10) { if (msg) { msg.textContent = "Please enter a valid 10-digit mobile number."; msg.classList.add("show", "err"); } return; }
            if (privacy && !privacy.checked) { if (msg) { msg.textContent = "Please accept the privacy affirmation."; msg.classList.add("show", "err"); } return; }
            if (btn) { btn.disabled = true; btn.textContent = "Sending..."; }
            setTimeout(function () {
                if (btn) { btn.disabled = false; btn.textContent = "Request Free Consultation"; }
                form.style.display = "none";
                if (thanks) {
                    var ph = thanks.querySelector(".thank-phone");
                    var nm = thanks.querySelector(".thank-name");
                    if (ph) ph.textContent = phone;
                    if (nm) nm.textContent = name.split(" ")[0];
                    thanks.classList.add("show");
                }
            }, 700);
        });
    }

    function formSubmit(form) {
        // ⚠️ Replace this with your deployed Google Apps Script Web App URL
        // const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzS6RE8oZEESfefDyaUwaI8BY-j1zpT6XwNt7wvEh5VByg8nCfvGj1K0GG7zwUejaWeWQ/exec";
        const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbyOJB8y5OBglJ6_sIofpVrk8BfNF0EsYQEpcrbWklTUJlHIljvEubXNWqvb24jhaIEq/exec"

        // Each form has its own message + submit button (two forms on the page:
        // the hero form and the modal form). Never share ids across them.
        const msg = form.querySelector(".msg") || form.parentElement.querySelector(".form-msg");
        const btn = form.querySelector(".submit");
        const btnLabel = btn ? btn.textContent : 'Submit';


        form.addEventListener('submit', async function (e) {
            e.preventDefault();
            if (msg) { msg.className = 'msg'; msg.textContent = ''; }

            if (!form.checkValidity()) { form.reportValidity(); return; }

            const data = {
                name: form.name.value.trim(),
                phone: form.phone.value.trim(),
                email: form.email.value.trim(),
                service: form.service.value,
                message: form?.message?.value?.trim(),
                page: window.location.href,
                timestamp: new Date().toISOString()
            };

            btn.disabled = true;
            btn.textContent = 'Sending...';

            try {
                await fetch(SCRIPT_URL, {
                    method: 'POST',
                    mode: 'no-cors',
                    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                    body: JSON.stringify(data)
                });
                window.location.href = 'thank-you.html?name=' + encodeURIComponent(data.name);
                return;
            } catch (err) {
                if (msg) {
                    msg.textContent = "Something went wrong. Please call us directly at +91 95600 25568.";
                    msg.classList.add('show', 'err');
                }
            } finally {
                btn.disabled = false;
                btn.textContent = btnLabel;
            }
        });
    }

    function initForms() {
        // qsa("form.js-book").forEach(bindForm);
        qsa("form.js-book").forEach(formSubmit);
        qsa("[data-reset-form]").forEach(function (b) {
            b.addEventListener("click", function () {
                var card = b.closest(".form-card");
                if (!card) return;
                var form = card.querySelector("form");
                var thanks = card.querySelector(".thanks");
                if (form) { form.reset(); form.style.display = "block"; }
                if (thanks) thanks.classList.remove("show");
            });
        });
    }

    function initFaq() {
        qsa(".faq-q").forEach(function (btn) {
            btn.addEventListener("click", function () {
                var item = btn.closest(".faq-item");
                var open = item.classList.contains("open");
                qsa(".faq-item").forEach(function (el) { el.classList.remove("open"); });
                if (!open) item.classList.add("open");
            });
        });
        var search = qs("#faqSearch");
        if (search) {
            search.addEventListener("input", function () {
                var q = search.value.toLowerCase();
                qsa(".faq-item").forEach(function (item) {
                    item.style.display = item.textContent.toLowerCase().indexOf(q) === -1 ? "none" : "";
                });
            });
        }
    }

    function initServices() {
        qsa(".more-btn").forEach(function (btn) {
            btn.addEventListener("click", function () {
                var grid = document.getElementById(btn.getAttribute("data-target"));
                if (!grid) return;
                var open = grid.classList.toggle("expanded");
                var lab = btn.querySelector("span");
                if (lab) lab.textContent = open ? "Show Less" : btn.getAttribute("data-closed");
            });
        });
        qsa(".tabs button").forEach(function (btn) {
            btn.addEventListener("click", function () {
                qsa(".tabs button").forEach(function (b) { b.classList.remove("active"); });
                btn.classList.add("active");
                var tab = btn.getAttribute("data-tab");
                qsa(".tab-panel").forEach(function (p) { p.style.display = p.id === tab ? "block" : "none"; });
            });
        });
        qsa(".svc, .treat").forEach(function (el) {
            el.addEventListener("click", openModal);
        });
    }

    function initMenu() {
        var drawer = qs("#drawer"), open = qs("#menuBtn"), close = qs("#drawerClose");
        function show() { if (drawer) drawer.classList.add("open"); }
        function hide() { if (drawer) drawer.classList.remove("open"); }
        if (open) open.addEventListener("click", show);
        if (close) close.addEventListener("click", hide);
        if (drawer) {
            drawer.addEventListener("click", function (e) { if (e.target === drawer) hide(); });
            qsa("a", drawer).forEach(function (a) { a.addEventListener("click", hide); });
        }
    }

    function openModal() { var m = qs("#bookModal"); if (m) m.classList.add("open"); }
    function closeModal() { var m = qs("#bookModal"); if (m) m.classList.remove("open"); }
    function initModal() {
        qsa("[data-open-book]").forEach(function (el) {
            el.addEventListener("click", function (e) { e.preventDefault(); openModal(); });
        });
        var x = qs("#bookModalClose"), m = qs("#bookModal");
        if (x) x.addEventListener("click", closeModal);
        if (m) m.addEventListener("click", function (e) { if (e.target === m) closeModal(); });

        // Auto-open once per page load, 15s after load. Once the visitor has
        // opened or closed it, don't pop it again until a full page reload.
        var autoTimer = setTimeout(function () {
            if (m && !m.classList.contains("open")) openModal();
        }, 15000);
        function cancelAuto() { clearTimeout(autoTimer); }
        if (x) x.addEventListener("click", cancelAuto);
        if (m) m.addEventListener("click", cancelAuto);
        qsa("[data-open-book]").forEach(function (el) { el.addEventListener("click", cancelAuto); });
    }

    function initVideo() {
        var fab = qs("#videoFab");
        var url = "https://drive.google.com/file/d/1l7nruKCdzuXpNzuf6zD6sklmOBQWpRCY/preview";
        if (fab) setTimeout(function () { fab.classList.add("show"); }, 1600);
        var cx = qs("#videoFabClose");
        if (cx) cx.addEventListener("click", function (e) { e.stopPropagation(); fab.classList.add("hide"); });
        var modal = qs("#videoModal"), frame = qs("#videoFrame");
        function openV(src) { if (!modal || !frame) return; frame.src = src || url; modal.classList.add("open"); }
        if (fab) fab.addEventListener("click", function () { openV(url); });
        var close = qs("#videoModalClose");
        if (close) close.addEventListener("click", function () { modal.classList.remove("open"); frame.src = ""; });
        if (modal) modal.addEventListener("click", function (e) { if (e.target === modal) { modal.classList.remove("open"); frame.src = ""; } });
    }

    function initGallery() {
        var box = qs("#lightbox"), img = qs("#lightboxImg");
        qsa(".gallery img").forEach(function (el) {
            el.addEventListener("click", function () { if (!box || !img) return; img.src = el.src; box.classList.add("open"); });
        });
        function hide() { if (box) box.classList.remove("open"); }
        var c = qs("#lightboxClose");
        if (c) c.addEventListener("click", hide);
        if (box) box.addEventListener("click", function (e) { if (e.target === box) hide(); });
    }

    function initQuiz() {
        var wrap = qs("#quizBox");
        if (!wrap) return;
        var questions = [
            { q: "How long have you been trying to conceive?", opts: ["Less than 6 months", "6–12 months", "1–3 years", "More than 3 years"] },
            { q: "What is the female partner’s age?", opts: ["Under 30", "30–34", "35–39", "40+"] },
            { q: "Have you had fertility treatment before?", opts: ["None yet", "Medicines / timed intercourse", "IUI", "Failed IVF cycle(s)"] },
            { q: "What is your main concern right now?", opts: ["PCOS / irregular cycles", "Male factor", "Blocked tubes / fibroids", "Unexplained / just starting"] }
        ];
        var step = 0, answers = [];
        var qEl = qs("#quizQuestion"), optsEl = qs("#quizOpts"), bar = qs("#quizBarFill"), result = qs("#quizResult"), card = qs("#quizCard");
        function render() {
            if (step >= questions.length) {
                card.style.display = "none";
                result.classList.add("show");
                var title = "Personalised fertility work-up";
                var body = "A full evaluation for both partners, then a plan built around your reports — not a default protocol.";
                if (String(answers[2] || "").indexOf("Failed") !== -1) {
                    title = "Failed IVF second-opinion review";
                    body = "Bring prior cycle records. Dr. Singla reviews stimulation, embryo quality and lining before recommending the next step.";
                } else if (String(answers[3] || "").indexOf("Male") !== -1) {
                    title = "Male-factor evaluation & ICSI pathway";
                    body = "Semen analysis and coordinated treatment, including ICSI when fertilisation needs extra support.";
                }
                qs("#quizRecTitle").textContent = title;
                qs("#quizRecBody").textContent = body;
                return;
            }
            var item = questions[step];
            qEl.textContent = item.q;
            optsEl.innerHTML = "";
            item.opts.forEach(function (opt) {
                var b = document.createElement("button");
                b.type = "button"; b.className = "qopt"; b.textContent = opt;
                b.addEventListener("click", function () { answers.push(opt); step += 1; render(); });
                optsEl.appendChild(b);
            });
            if (bar) bar.style.width = ((step + 1) / questions.length) * 100 + "%";
        }
        var restart = qs("#quizRestart");
        if (restart) restart.addEventListener("click", function () {
            step = 0; answers = []; result.classList.remove("show"); card.style.display = "block"; render();
        });
        render();
    }

    function decorateCards() {
        qsa(".svc").forEach(function (el) {
            if (el.querySelector(".go")) return;
            var d = document.createElement("div");
            d.className = "go";
            d.innerHTML = "<span>Consult on this</span>";
            el.appendChild(d);
        });
        qsa(".story").forEach(function (el) {
            if (el.querySelector(".qmark")) return;
            var q = document.createElement("div");
            q.className = "qmark";
            q.textContent = "“";
            el.appendChild(q);
        });
    }

    document.addEventListener("DOMContentLoaded", function () {
        initHeader(); initCarousel(); initForms(); initFaq(); initServices();
        initMenu(); initModal(); initVideo(); initGallery(); initQuiz();
        decorateCards();
    });
    const currentYearEl = document.querySelector('.current-year');
    const currentYear = new Date().getFullYear();
    currentYearEl.textContent = currentYear;
    // currentYearEls.forEach(el => el.textContent = currentYear);
})();
